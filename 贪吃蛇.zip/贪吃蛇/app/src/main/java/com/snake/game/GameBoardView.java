package com.snake.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.GestureDetector;

/**
 * 游戏棋盘视图
 * 绘制游戏界面，处理触摸事件
 */
public class GameBoardView extends View {
    
    // 游戏状态常量
    public static final int STATE_READY = 0;
    public static final int STATE_PLAYING = 1;
    public static final int STATE_PAUSED = 2;
    public static final int STATE_GAME_OVER = 3;
    
    // 游戏对象
    private Snake playerSnake;
    private AISnake aiSnake;
    private Food food;
    
    // 游戏状态
    private int gameState;
    private int playerScore;
    private int aiScore;
    private int boardWidth;
    private int boardHeight;
    
    // 绘图相关
    private float cellSize;
    private float offsetX;
    private float offsetY;
    private Paint gridPaint;
    private Paint playerPaint;
    private Paint playerHeadPaint;
    private Paint aiPaint;
    private Paint aiHeadPaint;
    private Paint foodPaint;
    private Paint textPaint;
    private Paint backgroundPaint;
    
    // 手势检测器
    private GestureDetector gestureDetector;
    
    // 游戏速度控制
    private int gameSpeed = 200; // 毫秒
    private Runnable gameLoopRunnable;
    private android.os.Handler gameHandler;
    
    // 回调接口
    private GameCallback callback;
    
    public interface GameCallback {
        void onScoreChanged(int playerScore, int aiScore);
        void onGameOver(String winner);
        void onGameStateChanged(int state);
    }
    
    public GameBoardView(Context context) {
        super(context);
        init();
    }
    
    public GameBoardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    
    public GameBoardView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }
    
    private void init() {
        // 初始化画笔
        backgroundPaint = new Paint();
        backgroundPaint.setColor(Color.rgb(20, 20, 40)); // 深蓝色背景
        
        gridPaint = new Paint();
        gridPaint.setColor(Color.rgb(50, 50, 70)); // 深色网格
        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(1);
        
        playerPaint = new Paint();
        playerPaint.setColor(Color.rgb(0, 200, 100)); // 绿色玩家蛇
        playerPaint.setStyle(Paint.Style.FILL);
        playerPaint.setAntiAlias(true);
        
        playerHeadPaint = new Paint();
        playerHeadPaint.setColor(Color.rgb(0, 255, 130)); // 更亮的绿色头部
        playerHeadPaint.setStyle(Paint.Style.FILL);
        playerHeadPaint.setAntiAlias(true);
        
        aiPaint = new Paint();
        aiPaint.setColor(Color.rgb(200, 50, 50)); // 红色AI蛇
        aiPaint.setStyle(Paint.Style.FILL);
        aiPaint.setAntiAlias(true);
        
        aiHeadPaint = new Paint();
        aiHeadPaint.setColor(Color.rgb(255, 80, 80)); // 更亮的红色头部
        aiHeadPaint.setStyle(Paint.Style.FILL);
        aiHeadPaint.setAntiAlias(true);
        
        foodPaint = new Paint();
        foodPaint.setColor(Color.rgb(255, 215, 0)); // 金色食物
        foodPaint.setStyle(Paint.Style.FILL);
        foodPaint.setAntiAlias(true);
        
        textPaint = new Paint();
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(40);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setAntiAlias(true);
        
        // 初始化游戏参数
        boardWidth = 15;
        boardHeight = 15;
        
        // 创建游戏对象
        playerSnake = new Snake(boardWidth / 4, boardHeight / 2);
        aiSnake = new AISnake(boardWidth * 3 / 4, boardHeight / 2, boardWidth, boardHeight);
        food = new Food();
        
        // 初始状态
        gameState = STATE_READY;
        playerScore = 0;
        aiScore = 0;
        
        // 手势检测
        gestureDetector = new GestureDetector(getContext(), new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(android.view.MotionEvent e1, android.view.MotionEvent e2, float velocityX, float velocityY) {
                if (gameState != STATE_PLAYING) return false;
                
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                
                if (Math.abs(dx) > Math.abs(dy)) {
                    // 水平滑动
                    if (dx > 0) {
                        playerSnake.setDirection(Snake.RIGHT);
                    } else {
                        playerSnake.setDirection(Snake.LEFT);
                    }
                } else {
                    // 垂直滑动
                    if (dy > 0) {
                        playerSnake.setDirection(Snake.DOWN);
                    } else {
                        playerSnake.setDirection(Snake.UP);
                    }
                }
                return true;
            }
            
            @Override
            public boolean onSingleTapUp(android.view.MotionEvent e) {
                if (gameState == STATE_READY) {
                    startGame();
                    return true;
                } else if (gameState == STATE_GAME_OVER) {
                    resetGame();
                    return true;
                }
                return false;
            }
        });
        
        // 游戏循环Handler - 使用传统Runnable方式
        gameHandler = new android.os.Handler() {
            @Override
            public void handleMessage(android.os.Message msg) {
                if (msg.what == 1) {
                    updateGame();
                    invalidate();
                    if (gameState == STATE_PLAYING) {
                        scheduleGameLoop();
                    }
                }
            }
        };
        
        gameLoopRunnable = new Runnable() {
            @Override
            public void run() {
                // 使用Handler发送消息而不是直接调用
                android.os.Message msg = new android.os.Message();
                msg.what = 1;
                gameHandler.sendMessage(msg);
            }
        };
    }
    
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int size = Math.min(getMeasuredWidth(), getMeasuredHeight());
        setMeasuredDimension(size, size);
    }
    
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        
        // 计算格子大小和偏移量
        float totalWidth = w;
        float totalHeight = h;
        cellSize = Math.min(totalWidth / boardWidth, totalHeight / boardHeight);
        offsetX = (totalWidth - cellSize * boardWidth) / 2;
        offsetY = (totalHeight - cellSize * boardHeight) / 2;
    }
    
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        int width = getWidth();
        int height = getHeight();
        
        // 绘制背景
        canvas.drawRect(0, 0, width, height, backgroundPaint);
        
        // 绘制网格
        for (int i = 0; i <= boardWidth; i++) {
            float x = offsetX + i * cellSize;
            canvas.drawLine(x, offsetY, x, offsetY + boardHeight * cellSize, gridPaint);
        }
        for (int i = 0; i <= boardHeight; i++) {
            float y = offsetY + i * cellSize;
            canvas.drawLine(offsetX, y, offsetX + boardWidth * cellSize, y, gridPaint);
        }
        
        // 绘制食物
        if (food.getPosition() != null) {
            float fx = offsetX + food.getPosition().x * cellSize + cellSize / 2;
            float fy = offsetY + food.getPosition().y * cellSize + cellSize / 2;
            canvas.drawCircle(fx, fy, cellSize * 0.35f, foodPaint);
        }
        
        // 绘制玩家蛇身
        for (int i = 0; i < playerSnake.getBody().size(); i++) {
            Point p = playerSnake.getBody().get(i);
            float x = offsetX + p.x * cellSize;
            float y = offsetY + p.y * cellSize;
            float padding = cellSize * 0.05f;
            
            Paint paint = (i == 0) ? playerHeadPaint : playerPaint;
            RectF rect = new RectF(x + padding, y + padding, x + cellSize - padding, y + cellSize - padding);
            canvas.drawRoundRect(rect, cellSize * 0.2f, cellSize * 0.2f, paint);
        }
        
        // 绘制AI蛇身
        for (int i = 0; i < aiSnake.getBody().size(); i++) {
            Point p = aiSnake.getBody().get(i);
            float x = offsetX + p.x * cellSize;
            float y = offsetY + p.y * cellSize;
            float padding = cellSize * 0.05f;
            
            Paint paint = (i == 0) ? aiHeadPaint : aiPaint;
            RectF rect = new RectF(x + padding, y + padding, x + cellSize - padding, y + cellSize - padding);
            canvas.drawRoundRect(rect, cellSize * 0.2f, cellSize * 0.2f, paint);
        }
        
        // 绘制分数
        textPaint.setTextSize(24);
        canvas.drawText("玩家(绿): " + playerScore, offsetX + 20, offsetY - 10, textPaint);
        canvas.drawText("AI(红): " + aiScore, offsetX + boardWidth * cellSize - 120, offsetY - 10, textPaint);
        
        // 绘制游戏状态提示
        if (gameState == STATE_READY) {
            textPaint.setTextSize(30);
            canvas.drawText("滑动屏幕控制方向", width / 2, height / 2 - 40, textPaint);
            canvas.drawText("点击开始游戏", width / 2, height / 2, textPaint);
        } else if (gameState == STATE_PAUSED) {
            textPaint.setTextSize(30);
            canvas.drawText("游戏暂停", width / 2, height / 2, textPaint);
        } else if (gameState == STATE_GAME_OVER) {
            textPaint.setTextSize(35);
            String winner = playerScore > aiScore ? "玩家获胜!" : 
                           (playerScore < aiScore ? "AI获胜!" : "平局!");
            canvas.drawText("游戏结束", width / 2, height / 2 - 40, textPaint);
            canvas.drawText(winner, width / 2, height / 2, textPaint);
            canvas.drawText("点击重新开始", width / 2, height / 2 + 40, textPaint);
        }
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (gestureDetector != null) {
            gestureDetector.onTouchEvent(event);
        }
        return true;
    }
    
    private void startGame() {
        gameState = STATE_PLAYING;
        spawnFood();
        scheduleGameLoop();
        if (callback != null) callback.onGameStateChanged(gameState);
    }
    
    private void resetGame() {
        playerSnake.reset(boardWidth / 4, boardHeight / 2);
        aiSnake.reset(boardWidth * 3 / 4, boardHeight / 2);
        playerScore = 0;
        aiScore = 0;
        gameState = STATE_READY;
        invalidate();
        if (callback != null) callback.onGameStateChanged(gameState);
    }
    
    private void scheduleGameLoop() {
        if (gameHandler != null && gameLoopRunnable != null) {
            gameHandler.postDelayed(gameLoopRunnable, gameSpeed);
        }
    }
    
    private void spawnFood() {
        food.spawn(boardWidth, boardHeight, playerSnake.getBody(), aiSnake.getBody());
    }
    
    private void updateGame() {
        if (gameState != STATE_PLAYING) return;
        
        // AI决策
        aiSnake.think(food.getPosition(), playerSnake.getBody(), aiSnake.getBody());
        
        // 计算玩家蛇移动后的位置
        Point futurePlayerHead = getFutureHead(playerSnake);
        boolean playerWillEat = food.getPosition() != null && futurePlayerHead.equals(food.getPosition());
        
        // 计算AI蛇移动后的位置
        Point futureAiHead = getFutureHead(aiSnake);
        boolean aiWillEat = food.getPosition() != null && futureAiHead.equals(food.getPosition());
        
        // 检查碰撞（移动前检查）
        // 检查玩家蛇移动后是否会撞墙
        if (futurePlayerHead.x < 0 || futurePlayerHead.x >= boardWidth || 
            futurePlayerHead.y < 0 || futurePlayerHead.y >= boardHeight) {
            gameState = STATE_GAME_OVER;
            if (callback != null) callback.onGameOver("AI获胜!");
            return;
        }
        
        // 检查玩家蛇移动后是否会撞到自身（不包括头部）
        for (int i = 1; i < playerSnake.getBody().size(); i++) {
            if (futurePlayerHead.equals(playerSnake.getBody().get(i))) {
                gameState = STATE_GAME_OVER;
                if (callback != null) callback.onGameOver("AI获胜!");
                return;
            }
        }
        
        // 检查玩家蛇移动后是否会撞到AI蛇
        for (Point p : aiSnake.getBody()) {
            if (futurePlayerHead.equals(p)) {
                gameState = STATE_GAME_OVER;
                if (callback != null) callback.onGameOver("玩家撞到AI，AI获胜!");
                return;
            }
        }
        
        // 检查AI蛇移动后是否会撞墙
        if (futureAiHead.x < 0 || futureAiHead.x >= boardWidth || 
            futureAiHead.y < 0 || futureAiHead.y >= boardHeight) {
            gameState = STATE_GAME_OVER;
            if (callback != null) callback.onGameOver("玩家获胜!");
            return;
        }
        
        // 检查AI蛇移动后是否会撞到自身（不包括头部）
        for (int i = 1; i < aiSnake.getBody().size(); i++) {
            if (futureAiHead.equals(aiSnake.getBody().get(i))) {
                gameState = STATE_GAME_OVER;
                if (callback != null) callback.onGameOver("玩家获胜!");
                return;
            }
        }
        
        // 检查AI蛇移动后是否会撞到玩家蛇
        for (Point p : playerSnake.getBody()) {
            if (futureAiHead.equals(p)) {
                gameState = STATE_GAME_OVER;
                if (callback != null) callback.onGameOver("AI撞到玩家，玩家获胜!");
                return;
            }
        }
        
        // 移动玩家蛇
        Point newPlayerHead = playerSnake.move(playerWillEat);
        
        // 检查玩家是否吃到食物
        if (playerWillEat) {
            playerScore += 10;
            spawnFood();
            if (callback != null) callback.onScoreChanged(playerScore, aiScore);
        }
        
        // 移动AI蛇
        Point newAiHead = aiSnake.move(aiWillEat);
        
        // 检查AI是否吃到食物
        if (aiWillEat) {
            aiScore += 10;
            spawnFood();
            if (callback != null) callback.onScoreChanged(playerScore, aiScore);
        }
    }
    
    // 计算蛇移动后的头部位置
    private Point getFutureHead(Snake snake) {
        Point head = snake.getHead();
        int direction = snake.getDirection();
        
        switch (direction) {
            case Snake.UP:
                return new Point(head.x, head.y - 1);
            case Snake.RIGHT:
                return new Point(head.x + 1, head.y);
            case Snake.DOWN:
                return new Point(head.x, head.y + 1);
            case Snake.LEFT:
                return new Point(head.x - 1, head.y);
            default:
                return new Point(head.x + 1, head.y);
        }
    }
    
    public int getGameState() {
        return gameState;
    }
    
    public void setCallback(GameCallback callback) {
        this.callback = callback;
    }
    
    public void setGameSpeed(int speed) {
        this.gameSpeed = speed;
    }
    
    public void pauseGame() {
        if (gameState == STATE_PLAYING) {
            gameState = STATE_PAUSED;
            if (gameHandler != null && gameLoopRunnable != null) {
                gameHandler.removeCallbacks(gameLoopRunnable);
            }
            if (callback != null) callback.onGameStateChanged(gameState);
            invalidate();
        }
    }
    
    public void resumeGame() {
        if (gameState == STATE_PAUSED) {
            gameState = STATE_PLAYING;
            scheduleGameLoop();
            if (callback != null) callback.onGameStateChanged(gameState);
        }
    }
}