package com.snake.game;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * AI控制的贪吃蛇
 * 使用BFS寻路算法寻找食物，同时避免碰撞
 */
public class AISnake extends Snake {
    
    private int boardWidth;
    private int boardHeight;
    
    public AISnake(int startX, int startY, int boardWidth, int boardHeight) {
        super(startX, startY);
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;
        setDirection(LEFT); // AI初始向左移动
    }
    
    /**
     * AI决策：计算下一步方向
     * @param foodPosition 食物位置
     * @param playerBody 玩家蛇身
     * @param aiBody AI蛇身（包括自身）
     */
    public void think(Point foodPosition, List<Point> playerBody, List<Point> aiBody) {
        if (foodPosition == null) {
            avoidWallsAndSelf(aiBody);
            return;
        }
        
        // 获取所有障碍物位置
        List<Point> obstacles = new ArrayList<>();
        obstacles.addAll(playerBody);
        obstacles.addAll(aiBody);
        
        // 尝试BFS寻路到食物
        int[] nextDir = bfsSearch(getHead(), foodPosition, obstacles);
        
        if (nextDir != null) {
            // 检查沿着这个方向走是否安全（不会立即撞到自己）
            int simDir = nextDir[0];
            Point newHead = getSimulatedHead(getHead(), simDir);
            if (isPositionSafe(newHead, obstacles)) {
                setDirection(simDir);
                return;
            }
        }
        
        // 如果无法安全到达食物，选择一个安全的方向
        avoidWallsAndSelf(obstacles);
    }
    
    /**
     * BFS寻路：找到从起点到终点的方向
     * @return int[]{方向} 或 null（找不到路径）
     */
    private int[] bfsSearch(Point start, Point target, List<Point> obstacles) {
        int width = boardWidth;
        int height = boardHeight;
        
        // visited数组
        boolean[][] visited = new boolean[width][height];
        // 记录每个位置的来源方向和前一个位置
        int[][] fromDir = new int[width][height];
        Point[][] fromPos = new Point[width][height];
        
        Queue<Point> queue = new LinkedList<>();
        queue.add(start);
        visited[start.x][start.y] = true;
        
        int[][] dirs = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}}; // 上右下左
        int[] dirValues = {Snake.UP, Snake.RIGHT, Snake.DOWN, Snake.LEFT};
        
        while (!queue.isEmpty()) {
            Point current = queue.poll();
            
            if (current.equals(target)) {
                // 回溯找到第一步方向
                Point p = current;
                while (fromPos[p.x][p.y] != null && !fromPos[p.x][p.y].equals(start)) {
                    p = fromPos[p.x][p.y];
                }
                return new int[]{fromDir[p.x][p.y]};
            }
            
            for (int i = 0; i < 4; i++) {
                int nx = current.x + dirs[i][0];
                int ny = current.y + dirs[i][1];
                
                if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
                if (visited[nx][ny]) continue;
                
                // 检查是否是障碍物（排除目标位置，因为目标就是食物）
                Point np = new Point(nx, ny);
                if (!np.equals(target) && isObstacle(np, obstacles)) continue;
                
                visited[nx][ny] = true;
                fromDir[nx][ny] = dirValues[i];
                fromPos[nx][ny] = current;
                queue.add(np);
            }
        }
        
        return null; // 找不到路径
    }
    
    /**
     * 检查位置是否是障碍物
     */
    private boolean isObstacle(Point p, List<Point> obstacles) {
        for (Point ob : obstacles) {
            if (p.equals(ob)) return true;
        }
        return false;
    }
    
    /**
     * 获取某个方向的新头部位置
     */
    private Point getSimulatedHead(Point head, int dir) {
        switch (dir) {
            case Snake.UP:    return new Point(head.x, head.y - 1);
            case Snake.RIGHT: return new Point(head.x + 1, head.y);
            case Snake.DOWN:  return new Point(head.x, head.y + 1);
            case Snake.LEFT:  return new Point(head.x - 1, head.y);
            default:          return new Point(head.x + 1, head.y);
        }
    }
    
    /**
     * 检查位置是否安全（不在障碍物中，不越界）
     */
    private boolean isPositionSafe(Point p, List<Point> obstacles) {
        if (p.x < 0 || p.x >= boardWidth || p.y < 0 || p.y >= boardHeight) {
            return false;
        }
        return !isObstacle(p, obstacles);
    }
    
    /**
     * 避开墙壁和自身的决策
     * 选择一个不会立即死亡的方向
     */
    private void avoidWallsAndSelf(List<Point> obstacles) {
        Point head = getHead();
        int[] dirs = {Snake.UP, Snake.RIGHT, Snake.DOWN, Snake.LEFT};
        
        // 按当前方向优先，然后尝试其他方向
        int currentDir = getDirection();
        int[] priority = new int[4];
        priority[0] = currentDir;
        int idx = 1;
        for (int i = 0; i < 4; i++) {
            if (dirs[i] != currentDir) {
                priority[idx++] = dirs[i];
            }
        }
        
        for (int dir : priority) {
            Point newHead = getSimulatedHead(head, dir);
            if (isPositionSafe(newHead, obstacles)) {
                // 额外检查：这个方向之后是否还有路
                List<Point> tempObstacles = new ArrayList<>(obstacles);
                // 模拟移动后检查是否有可走的路
                setDirection(dir);
                return;
            }
        }
        
        // 如果所有方向都不安全，保持当前方向（等待死亡）
    }
}