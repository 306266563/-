package com.snake.game;

import java.util.List;
import java.util.Random;

/**
 * 食物类
 */
public class Food {
    private Point position;
    private Random random;
    
    public Food() {
        random = new Random();
    }
    
    public Point getPosition() {
        return position;
    }
    
    /**
     * 在空闲位置生成食物
     */
    public void spawn(int boardWidth, int boardHeight, List<Point> playerBody, List<Point> aiBody) {
        int x, y;
        boolean valid;
        int attempts = 0;
        do {
            x = random.nextInt(boardWidth);
            y = random.nextInt(boardHeight);
            valid = true;
            
            // 检查是否与玩家蛇重叠
            for (Point p : playerBody) {
                if (p.x == x && p.y == y) {
                    valid = false;
                    break;
                }
            }
            
            // 检查是否与AI蛇重叠
            if (valid) {
                for (Point p : aiBody) {
                    if (p.x == x && p.y == y) {
                        valid = false;
                        break;
                    }
                }
            }
            
            attempts++;
        } while (!valid && attempts < 1000);
        
        position = new Point(x, y);
    }
    
    /**
     * 检查是否被吃掉
     */
    public boolean isEaten(Point point) {
        return position != null && position.equals(point);
    }
}