package com.snake.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity implements GameBoardView.GameCallback {
    
    private GameBoardView gameBoard;
    private TextView scoreText;
    private TextView statusText;
    private Button startButton;
    private Button pauseButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 创建主布局
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT));
        mainLayout.setBackgroundColor(android.graphics.Color.rgb(20, 20, 40));
        mainLayout.setPadding(20, 20, 20, 20);
        
        // 标题
        TextView titleText = new TextView(this);
        titleText.setText("贪吃蛇大战");
        titleText.setTextSize(28);
        titleText.setTextColor(android.graphics.Color.WHITE);
        titleText.setGravity(android.view.Gravity.CENTER);
        titleText.setPadding(0, 20, 0, 10);
        mainLayout.addView(titleText);
        
        // 分数显示
        scoreText = new TextView(this);
        scoreText.setText("玩家: 0  |  AI: 0");
        scoreText.setTextSize(18);
        scoreText.setTextColor(android.graphics.Color.rgb(200, 200, 200));
        scoreText.setGravity(android.view.Gravity.CENTER);
        scoreText.setPadding(0, 10, 0, 5);
        mainLayout.addView(scoreText);
        
        // 状态文本
        statusText = new TextView(this);
        statusText.setText("点击开始游戏");
        statusText.setTextSize(16);
        statusText.setTextColor(android.graphics.Color.rgb(100, 200, 255));
        statusText.setGravity(android.view.Gravity.CENTER);
        statusText.setPadding(0, 5, 0, 15);
        mainLayout.addView(statusText);
        
        // 棋盘容器（居中）
        LinearLayout boardContainer = new LinearLayout(this);
        boardContainer.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0, 1.0f));
        boardContainer.setGravity(android.view.Gravity.CENTER);
        
        // 创建棋盘
        LinearLayout.LayoutParams boardParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT);
        boardParams.setMargins(10, 0, 10, 0);
        
        gameBoard = new GameBoardView(this);
        gameBoard.setLayoutParams(boardParams);
        gameBoard.setCallback(this);
        boardContainer.addView(gameBoard);
        mainLayout.addView(boardContainer);
        
        // 底部按钮区域
        LinearLayout buttonLayout = new LinearLayout(this);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(android.view.Gravity.CENTER);
        buttonLayout.setPadding(0, 10, 0, 30);
        
        // 开始按钮
        startButton = new Button(this);
        startButton.setText("开始游戏");
        startButton.setTextSize(14);
        startButton.setPadding(20, 10, 20, 10);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gameBoard.getGameState() == GameBoardView.STATE_READY || 
                    gameBoard.getGameState() == GameBoardView.STATE_GAME_OVER) {
                    gameBoard.resetGame();
                    gameBoard.startGame();
                    statusText.setText("游戏中...");
                }
            }
        });
        buttonLayout.addView(startButton);
        
        // 暂停按钮
        pauseButton = new Button(this);
        pauseButton.setText("暂停");
        pauseButton.setTextSize(14);
        pauseButton.setPadding(20, 10, 20, 10);
        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gameBoard.getGameState() == GameBoardView.STATE_PLAYING) {
                    gameBoard.pauseGame();
                    pauseButton.setText("继续");
                } else if (gameBoard.getGameState() == GameBoardView.STATE_PAUSED) {
                    gameBoard.resumeGame();
                    pauseButton.setText("暂停");
                }
            }
        });
        buttonLayout.addView(pauseButton);
        
        mainLayout.addView(buttonLayout);
        
        // 添加游戏说明
        TextView helpText = new TextView(this);
        helpText.setText("控制说明:\n• 滑动屏幕控制方向\n• 绿色蛇=玩家\n• 红色蛇=AI\n• 金色圆点=食物\n• 吃到食物得10分\n• 撞墙或撞到对方失败");
        helpText.setTextSize(12);
        helpText.setTextColor(android.graphics.Color.rgb(150, 150, 150));
        helpText.setPadding(20, 10, 20, 10);
        mainLayout.addView(helpText);
        
        setContentView(mainLayout);
    }
    
    @Override
    public void onScoreChanged(int playerScore, int aiScore) {
        final int ps = playerScore;
        final int as = aiScore;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                scoreText.setText("玩家: " + ps + "  |  AI: " + as);
            }
        });
    }
    
    @Override
    public void onGameOver(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                statusText.setText(message);
                pauseButton.setText("暂停");
                
                // 显示游戏结束对话框
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("游戏结束");
                builder.setMessage(message);
                builder.setCancelable(false);
                builder.setPositiveButton("再来一局", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        gameBoard.resetGame();
                        gameBoard.startGame();
                        statusText.setText("游戏中...");
                    }
                });
                builder.setNegativeButton("退出", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.show();
            }
        });
    }
    
    @Override
    public void onGameStateChanged(final int state) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                switch (state) {
                    case GameBoardView.STATE_READY:
                        statusText.setText("点击开始游戏");
                        pauseButton.setText("暂停");
                        break;
                    case GameBoardView.STATE_PLAYING:
                        statusText.setText("游戏中...");
                        pauseButton.setText("暂停");
                        break;
                    case GameBoardView.STATE_PAUSED:
                        statusText.setText("游戏暂停");
                        pauseButton.setText("继续");
                        break;
                    case GameBoardView.STATE_GAME_OVER:
                        statusText.setText("游戏结束");
                        pauseButton.setText("暂停");
                        break;
                }
            }
        });
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        if (gameBoard != null) {
            gameBoard.pauseGame();
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
    }
}