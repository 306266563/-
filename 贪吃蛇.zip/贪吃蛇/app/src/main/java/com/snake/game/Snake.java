package com.snake.game;

import java.util.ArrayList;
import java.util.List;

/**
 * 贪吃蛇类，表示游戏中的蛇
 */
public class Snake {
    // 方向常量
    public static final int UP = 0;
    public static final int RIGHT = 1;
    public static final int DOWN = 2;
    public static final int LEFT = 3;
    
    // 蛇身位置列表，索引0是头部
    private List<Point> body;
    // 当前移动方向
    private int direction;
    // 蛇的长度
    private int length;
    
    public Snake(int startX, int startY) {
        body = new ArrayList<>();
        // 初始化蛇身，3节长度，从右向左
        body.add(new Point(startX, startY));
        body.add(new Point(startX - 1, startY));
        body.add(new Point(startX - 2, startY));
        direction = RIGHT;
        length = 3;
    }
    
    public List<Point> getBody() {
        return body;
    }
    
    public Point getHead() {
        return body.get(0);
    }
    
    public int getDirection() {
        return direction;
    }
    
    public void setDirection(int direction) {
        // 防止直接反向移动
        if (Math.abs(this.direction - direction) != 2) {
            this.direction = direction;
        }
    }
    
    public int getLength() {
        return length;
    }
    
    /**
     * 移动蛇
     * @param grow 是否增长（吃到食物时）
     * @return 新头部位置
     */
    public Point move(boolean grow) {
        Point head = getHead();
        Point newHead;
        
        switch (direction) {
            case UP:
                newHead = new Point(head.x, head.y - 1);
                break;
            case RIGHT:
                newHead = new Point(head.x + 1, head.y);
                break;
            case DOWN:
                newHead = new Point(head.x, head.y + 1);
                break;
            case LEFT:
                newHead = new Point(head.x - 1, head.y);
                break;
            default:
                newHead = new Point(head.x + 1, head.y);
        }
        
        // 添加新头部
        body.add(0, newHead);
        
        // 如果不增长，移除尾部
        if (!grow) {
            body.remove(body.size() - 1);
        } else {
            length++;
        }
        
        return newHead;
    }
    
    /**
     * 检查是否与自身碰撞
     */
    public boolean checkSelfCollision() {
        Point head = getHead();
        for (int i = 1; i < body.size(); i++) {
            if (head.equals(body.get(i))) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 检查是否与边界碰撞
     */
    public boolean checkWallCollision(int boardWidth, int boardHeight) {
        Point head = getHead();
        return head.x < 0 || head.x >= boardWidth || head.y < 0 || head.y >= boardHeight;
    }
    
    /**
     * 重置蛇
     */
    public void reset(int startX, int startY) {
        body.clear();
        body.add(new Point(startX, startY));
        body.add(new Point(startX - 1, startY));
        body.add(new Point(startX - 2, startY));
        direction = RIGHT;
        length = 3;
    }
}